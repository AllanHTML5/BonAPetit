/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3.AllanCore;
import FrontEnd.Gui;
import FrontEnd.lol;

/**
 *
 * @author Allan Flores
 */
public class Processor {
    
   public static void main(String[] args){
   Gui test = new Gui();
   test.show();
   lol xd = new lol();
   xd.show();
   System.out.println("asd");
   }
        
}
