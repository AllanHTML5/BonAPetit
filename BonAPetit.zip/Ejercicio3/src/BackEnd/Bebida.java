/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BackEnd;

/**
 *
 * @author Allan Flores
 */
public class Bebida extends PlatilloFuerte{
    
    private boolean Azucar;

    public Bebida(boolean Azucar) {
        this.Azucar = Azucar;
    }

    public boolean isAzucar() {
        return Azucar;
    }

    public void setAzucar(boolean Azucar) {
        this.Azucar = Azucar;
    }
    
    public Bebida(String nombre, int precio) {
        super(nombre, precio);
    }

    public Bebida() {
    }
    
    
        @Override
public String getNombre() { return this.name; }
    @Override
public int getPrecio() { return this.precio; }


    @Override
  public void setName(String name) {
      this.name = name;
  }

    @Override
  public void setPrecio(int precio) {
      this.precio = precio;
  }
        public void dataprinter(){
    System.out.println("-------------------------");
    System.out.println(" Bon A Petit Restaurant");
    System.out.println("      By AllanDev");
    System.out.println("-------------------------");
    System.out.println("Su bebida seleccionada del menú es:");
    System.out.println(getNombre());
    System.out.println("Su precio es:");
    System.out.println(getPrecio());
    System.out.println("¿Le agregará Azucar a su bebida?");
    System.out.println(isAzucar());
    System.out.println("---------------------------------------------");
    System.out.println("Subtotal= "+getPrecio());
    
}
}
