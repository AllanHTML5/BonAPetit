/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BackEnd;

/**
 *
 * @author Allan Flores
 */
public class PlatilloFuerte extends Instanciador{
private boolean Cuchara;
private boolean Pollo;
private boolean Carne;
private boolean Sal;
private boolean Tenedor;

    public PlatilloFuerte(boolean Cuchara, boolean Carne, boolean Sal, boolean Tenedor) {
        this.Cuchara = Cuchara;
        this.Carne = Carne;
        this.Sal = Sal;
        this.Tenedor = Tenedor;
    }

    
    public PlatilloFuerte(String nombre, int precio) {
        super(nombre, precio);
    }

    public PlatilloFuerte() {
    }

    public boolean isCuchara() {
        return Cuchara;
    }

    public void setCuchara(boolean Cuchara) {
        this.Cuchara = Cuchara;
    }

    public boolean isPollo() {
        return Pollo;
    }

    public void setPollo(boolean Pollo) {
        this.Pollo = Pollo;
    }

    public boolean isCarne() {
        return Carne;
    }

    public void setCarne(boolean Carne) {
        this.Carne = Carne;
    }

    public boolean isSal() {
        return Sal;
    }

    public void setSal(boolean Sal) {
        this.Sal = Sal;
    }

    public boolean isTenedor() {
        return Tenedor;
    }

    public void setTenedor(boolean Tenedor) {
        this.Tenedor = Tenedor;
    }

    
    
    
    
    @Override
public String getNombre() { return this.name; }
    @Override
public int getPrecio() { return this.precio; }


    @Override
  public void setName(String name) {
      this.name = name;
  }

    @Override
  public void setPrecio(int precio) {
      this.precio = precio;
  }


  public void dataprinter(){
    System.out.println("-------------------------");
    System.out.println(" Bon A Petit Restaurant");
    System.out.println("      By AllanDev");
    System.out.println("-------------------------");
    System.out.println("Su platillo seleccionado del menú es:");
    System.out.println(getNombre());
    System.out.println("Su precio es:");
    System.out.println(getPrecio());
    System.out.println("¿Usará cuchara para este plato?");
    System.out.println(isCuchara());
    System.out.println("¿Le agregará pollo a su plato?");
    System.out.println(isPollo());
    System.out.println("¿Le agregará Carne a su plato?");
    System.out.println(isCarne());
    System.out.println("¿Le agregará Sal a su plato?");
    System.out.println(isSal());
    System.out.println("¿Usará tenedor y cuchillo para este plato?");
    System.out.println(isTenedor());
    System.out.println("---------------------------------------------");
    System.out.println("Subtotal= "+getPrecio());
    
}
}