/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BackEnd;

/**
 *
 * @author Allan Flores
 */
public class Ensalada extends PlatilloFuerte{

    public Ensalada(String nombre, int precio) {
        super(nombre, precio);
    }
    
   
    
    
}
