/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BackEnd;

/**
 *
 * @author Allan Flores
 */
public class Postre extends Bebida{

    public Postre(boolean Azucar) {
        super(Azucar);
    }

    public Postre(String nombre, int precio) {
        super(nombre, precio);
    }

    public Postre() {
    }


    
   @Override
public String getNombre() { return this.name; }
    @Override
public int getPrecio() { return this.precio; }


    @Override
  public void setName(String name) {
      this.name = name;
  }

    @Override
  public void setPrecio(int precio) {
      this.precio = precio;
  }
    
    public void dataprinter(){
    System.out.println("-------------------------");
    System.out.println(" Bon A Petit Restaurant");
    System.out.println("      By AllanDev");
    System.out.println("-------------------------");
    System.out.println("Su platillo seleccionado del menú es:");
    System.out.println(getNombre());
    System.out.println("Su precio es:");
    System.out.println(getPrecio());
    System.out.println("¿Usará cuchara para este plato?");
    System.out.println(isCuchara());
    System.out.println("¿Usará tenedor y cuchillo para este plato?");
    System.out.println(isTenedor());
        System.out.println("¿Le Agregará Azucar a su postre?");
    System.out.println(isAzucar());
    System.out.println("---------------------------------------------");
    System.out.println("Subtotal= "+getPrecio());
    
}
}
