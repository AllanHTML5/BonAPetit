/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BackEnd;

/**
 *
 * @author Allan Flores
 */
public class Instanciador {
    
  /* fields */ 
  String name;	
  int precio;

    public Instanciador() {
    }

  /* constructor */
  Instanciador(String nombre, int precio) {
    this.name = nombre;
    this.precio = precio;
  }	 	 

  /* accessors */
  String getNombre() { return this.name; }
  int getPrecio() { return this.precio; }

  
    public void setName(String name) {
        this.name = name;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
  
    

    
  public void dataprinter(){
      System.out.println("-------------------------");
      System.out.println(" Bon A Petit Restaurant");
      System.out.println("      By AllanDev");
      System.out.println("-------------------------");
      System.out.println("Su platillo principal es:");
      System.out.println(getPrecio());
      System.out.println("Su precio es:");
      System.out.println(getNombre());
      System.out.println("Usará cuchara para este plato?");
      
  }
}
